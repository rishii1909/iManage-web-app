const withLess = require('@zeit/next-less');

module.exports = withLess({
  /* config options here */
});